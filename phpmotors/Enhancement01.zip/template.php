<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/snippets/header.php';
?>

<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/snippets/nav.php';
?>

<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/snippets/main.php';
?>

<?php
    require_once $_SERVER['DOCUMENT_ROOT'] . '/snippets/footer.php';
?>